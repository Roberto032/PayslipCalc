Requirements:
-Node 
-Express.js(npm i express)

To Run:
-CD into SRC
-Node server.js
-Visit http://localhost:4000 in Browser